package com.example.notesappfinalproject

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.notesappfinalproject.ui.theme.NotesAppFinalProjectTheme
import androidx.compose.ui.tooling.preview.Preview
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NotesAppFinalProjectTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    NotesApp(modifier = Modifier.padding(innerPadding))
                }
            }
        }
    }
}

@Composable
fun NotesApp(modifier: Modifier = Modifier) {
    var noteText by remember { mutableStateOf("") }
    var notesList by remember { mutableStateOf(listOf<String>()) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = noteText,
            onValueChange = { noteText = it },
            label = { Text("Write Down a note") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                if (noteText.isNotBlank()) {
                    notesList = notesList + noteText
                    noteText = ""
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Add Note")
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = {
                val context = LocalContext.current
                context.startActivity(Intent(context, HelpActivity::class.kt))
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Help")
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            items(notesList) { note ->
                NoteItem(
                    note = note,
                    onDelete = {
                        notesList = notesList - note
                    }
                )
            }
        }
    }
}

@Composable
fun NoteItem(note: String, onDelete: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(8.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(note)
            TextButton(onClick = onDelete) {
                Text("Delete")
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun NotesAppPreview() {
    NotesAppFinalProjectTheme {
        NotesApp()
    }
}
