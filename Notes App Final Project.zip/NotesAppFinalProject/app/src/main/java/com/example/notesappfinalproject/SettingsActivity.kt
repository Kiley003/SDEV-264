package com.example.notesappfinalproject

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(
    darkModeEnabled: Boolean,
    onDarkModeChanged: (Boolean) -> Unit,
    fontSize: String,
    onFontSizeChanged: (String) -> Unit,
    autoSaveEnabled: Boolean,
    onAutoSaveChanged: (Boolean) -> Unit
) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text("Settings", style = MaterialTheme.typography.titleLarge)

        Spacer(modifier = Modifier.height(16.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Dark Mode")
            Switch(
                checked = darkModeEnabled,
                onCheckedChange = onDarkModeChanged
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Font Size")
        DropdownMenuBox(
            selected = fontSize,
            options = listOf("Small", "Medium", "Large"),
            onOptionSelected = onFontSizeChanged
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("auto save")
            Switch(
                checked = autoSaveEnabled,
                onCheckedChange = onAutoSaveChanged
            )

        }
    }
}

@Composable
fun DropdownMenuBox(selected: String, options: List<String>, onOptionSelected: (String) -> Unit) {
    TODO("Not yet implemented")
}



