package com.example.notesappfinalproject

import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.notesappfinalproject.ui.theme.NotesAppFinalProjectTheme
import androidx.compose.ui.tooling.preview.Preview

@Composable
fun NotesAppFinalProject(modifier: Modifier = Modifier) {
        fun onCreate(savedInstanceState: Bundle?) {
                HelpScreen()
            }
        }


annotation class HelpScreen

@Composable
    fun Helpcreen() {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Text("Help", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(16.dp))
            Text("• Enter a note in the text field\n" +
                    "• Tap 'Add Note' to save it\n" +
                    "• Tap 'Delete' to remove a note\n" +
                    "• Use Settings to change font size, dark mode, or auto-save")
        }
    }

